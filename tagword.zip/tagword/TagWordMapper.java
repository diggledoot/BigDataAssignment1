package tagword;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class TagWordMapper extends Mapper<LongWritable,Text,Text,Text>{
	
	@Override
	public void map(LongWritable key,Text value,Context context) throws IOException,InterruptedException{
		if(key.get()==0){
			return;
		}else{
			String line = value.toString();
			Text title = new Text(line.split("\t")[2]);
			Text arr = new Text(line.split("\t")[8]+"\t"+line.split("\t")[6]);
			context.write(title, arr);
		}
	}

}
