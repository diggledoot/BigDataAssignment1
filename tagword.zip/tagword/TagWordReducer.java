package tagword;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Reducer;


public class TagWordReducer extends Reducer<Text,Text,Text,IntWritable>{
	
	@Override
	public void reduce(Text title,Iterable<Text> values,Context context) throws IOException,InterruptedException{
		int sum=0;
		for(Text val:values){
			sum+=Integer.parseInt(val.toString());
		}
		context.write(title,new IntWritable(sum));
	}

}
