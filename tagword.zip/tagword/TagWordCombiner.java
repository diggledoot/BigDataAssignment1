package tagword;

import java.util.regex.*;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class TagWordCombiner extends Reducer<Text,Text,Text,Text>{
	
	@Override
	public void reduce(Text title,Iterable<Text> values,Context context) throws IOException,InterruptedException{
		int sum = 0;
		for(Text val:values){
			String line=val.toString();
			int likes = Integer.parseInt(line.split("\t")[0]);
			String tags = line.split("\t")[1];
			
			Pattern r = Pattern.compile("\\bcute\\b",Pattern.CASE_INSENSITIVE);
			Matcher matcher = r.matcher(tags);
			boolean found = matcher.find();
			
			if(found & likes>3000){
				sum+=1;
			}
		}
		
		if(sum==0){
			return;
		}else{
			context.write(title,new Text(Integer.toString(sum)));
		}
	}

}
